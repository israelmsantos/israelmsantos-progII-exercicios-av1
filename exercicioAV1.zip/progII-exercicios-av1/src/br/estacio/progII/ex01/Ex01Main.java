package br.estacio.progII.ex01;

public class Ex01Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Ex01Frame();
		//Ex01Class calculo = new Ex01Class();
		//System.out.println(calculo.Calcular(9, 5, 22));
	}

}
